import { StyleSheet, Text, View } from "react-native";
import App from './src/App';
import Constants from "expo-constants";
import Storybook from "./.storybook";

let AppEntryPoint = App;
AppEntryPoint = Storybook;

if (Constants.expoConfig.extra.storybookEnabled === "true") {
  AppEntryPoint = Storybook;
}

export default AppEntryPoint;
