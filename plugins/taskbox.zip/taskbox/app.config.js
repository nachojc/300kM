export default ({ config }) => ({
  ...config,
  name: "Aviva Component Library",
  slug: "@aviva/ui",
  extra: {
    storybookEnabled: process.env.STORYBOOK_ENABLED,
  },
});
