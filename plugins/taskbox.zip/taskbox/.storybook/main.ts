// module.exports = {
//   stories: ["../src/**/*.stories.?(ts|tsx|js|jsx)"],
//   addons: [
//     "@storybook/addon-ondevice-controls",
//     "@storybook/addon-ondevice-actions",
//     {
//       name: '@storybook/addon-docs',
//       options: {
//         jsxOptions: {},
//         csfPluginOptions: null,
//         mdxPluginOptions: {},
//       },
//     },
//   ],
// };
module.exports =  {
  stories: [
    '../src/**/*.mdx',
    "../src/**/*.stories.?(ts|tsx|js|jsx)"
  ],
  addons: [
    "@storybook/addon-ondevice-controls",
    "@storybook/addon-ondevice-actions",
    "@storybook/addon-docs",
    // {
    //   name: "@storybook/addon-docs",
    //   options: {
    //     jsxOptions: {},
    //     csfPluginOptions: null,
    //     mdxPluginOptions: {},
    //   },
    // },
  ],
};
